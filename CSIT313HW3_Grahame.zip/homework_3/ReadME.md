# Assignment 3

# Author
- Kyler Grahame
- 10/27/24
- CSIT313_01

# Description 
- This Assignment is 2 parts, A and B. For part A.1, "Variable Names exist in Java and Python", there will be 6 files, in a folder called ProblemA1.1, correlating to the work to answer the 3 questions. They will be problemA1a.java or problemA1c.py for each question and will include a commented description at the top with the corresponding code to follow that will prove the statements. For part A.2, The code and answer will be in a file called problemA2. For part A.3, The code and answer will be in a file called problemA3. For part B, there is a folder called problem B which will contain the c, c++, and java codes in seperate files as well as a pdf or some .txt form file with the essay.