// Task1A


    public class Task1A
    {
        public static void main(String[] args)
        {

            int num = 10;
            if (num == 10) // 1st if
            {
                num = 5;
                System.out.println("Num is = " + num);
            } 
            // 1st else removed
            if (num == 10) //2nd if
            {
                num = 15;
                System.out.println("Num is = " + num);

            }
            else //2nd else
            {
                num = 30;
                System.out.println("Num is = " + num);

            }

        }
    }


